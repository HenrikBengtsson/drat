sfit::cfitOptions()

library("sfit")
cfitOptions()
