library("sfit")
cfitTests()
